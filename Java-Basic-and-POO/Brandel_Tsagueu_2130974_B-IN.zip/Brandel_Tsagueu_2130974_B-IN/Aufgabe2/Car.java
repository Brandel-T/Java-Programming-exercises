

public class Car {
	String marke;
	Car(String m) {
		marke = m;
	}
	 
	public String toString() { 
		return marke;
	}
}
